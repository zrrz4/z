#!/bin/bash

# Function to change the device ID for a specified package name
change_device_id() {
    local package_name=$1

    echo "Changing device ID for package: $package_name"

    # Granting permissions to access the data folder
    chmod 777 /data/data/$package_name

    # Removing shared preferences and database directories
    rm -rf /data/data/$package_name/shared_prefs
    rm -rf /data/data/$package_name/databases

    # Clear terminal screen (optional)
    clear

    # Get the existing device ID (SSAID) from settings_ssaid.xml
    X=$(grep -n "$package_name" /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"' | cut -d '"' -f2)

    # Generate a new random device ID
    Xx=$(head -3 /dev/urandom | tr -cd 'a-z0-9' | cut -c -16)

    # Replace the old device ID with the new one
    sed -i "s/$X/$Xx/g" /data/system/users/0/settings_ssaid.xml

    echo "Device ID changed from $X to $Xx"

    # Reboot the device to apply changes
    su -c reboot
}

# Function to determine which version to change device ID for
handle_device_id_change() {
    local version=$1

    case $version in
        "global")
            change_device_id "com.tencent.ig"  # Global version
            ;;
        "kr")
            change_device_id "com.pubg.krmobile"  # KR version
            ;;
        "tw")
            change_device_id "com.rekoo.pubgm"  # TW version
            ;;
        "vn")
            change_device_id "com.vng.pubgmobile"  # VN version
            ;;
        "india")
            change_device_id "com.pubg.imobile"  # India version
            ;;
        *)
            echo "Unknown version: $version"
            echo "Please use one of the following: global, kr, tw, vn, india"
            ;;
    esac
}

# Check if the script is run with a version argument
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <version>"
    echo "Version options: global, kr, tw, vn, india"
    exit 1
fi

# Call the function to handle device ID change for the specified version
handle_device_id_change "$1"

echo "Device ID change process completed for version: $1"